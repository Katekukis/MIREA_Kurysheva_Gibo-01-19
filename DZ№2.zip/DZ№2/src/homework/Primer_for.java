package homework;
import java.util.Scanner;

public class Primer_for {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        for (int i = 0; i < 100; i++) {
            System.out.println("Привет");
        }
    }
}